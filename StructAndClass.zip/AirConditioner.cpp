#include "AirConditioner.h"
#include <iostream>
using namespace std;

void AirConditioner::SetPower(bool power)
{
	this->power = power;
}

void AirConditioner::SetTemp(int temp)
{
	this->temp = temp;
}

void AirConditioner::UpTemp()
{
	++temp;
}

void AirConditioner::DownTemp()
{
	--temp;
}

void AirConditioner::PrintTemp()
{
	cout << "�µ� : " << temp << endl;
}

void AirConditioner::PrintPower()
{
	cout << "���� : " << (power ? "ON" : "OFF") << endl;
}
