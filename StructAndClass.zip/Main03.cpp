#include "Dog.h"

void main()
{
	Dog* myDog = new Dog;

	myDog->SetName("�۸���");
	myDog->SetAge(3);

	cout << "�̸� : " << myDog->GetName() << endl;
	cout << "���� : " << myDog->GetAge() << endl;

	delete myDog;
	myDog = nullptr;
}