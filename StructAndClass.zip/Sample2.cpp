#include "Sample2.h"

Sample2::Sample2(int data)
{
	cout << "Sample2(int data) ȣ��" << endl;

}

Sample2::Sample2(int data1, int data2)
{
}

Sample2::~Sample2()
{
}

void Sample2::Print()
{
}
