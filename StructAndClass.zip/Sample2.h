#pragma once
#include <iostream>
using namespace std;

class Sample2
{
private:
	int a;
	int b;

public:
	Sample2(int data);
	Sample2(int data1, int data2);
	~Sample2();

	void Print();
};

